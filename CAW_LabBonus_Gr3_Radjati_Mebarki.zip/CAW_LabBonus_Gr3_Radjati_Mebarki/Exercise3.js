//Q1
const arr2 = [3, 2,5,3,8,8,5, 8];
const setOne = arr => [...new Set(arr)];
console.log(setOne(arr2));
//Q2
const getRidOf = (tab, ...val) => tab.filter(item => !val.includes(item));
console.log(getRidOf(arr2,3,5));