 //Q1
 v1=5;
 v2=7;
 [v1,v2]=[v2,v1];
 console.log("After swapping:");
 console.log("v1 =", v1); 
 console.log("v2 =", v2); 
//Q2
 const numbers = [1, 2, 3];
const letters = ["a", "b", "c"];
const foods = ["mango", "pecan pie"];
const combined = [...numbers, ...letters, ...foods];
console.log(combined); 
//Q3
const str = "welcome";
const chars = [...str];
console.log(chars);
//Q4
function fn(a, b, ...args) {
    console.log(args);
  }
  
  // a) fn(1, 2, 3, 'A', 'B', 'C');
  // args will be: [3, 'A', 'B', 'C']
  
  // b) fn(1, 2);
  // args will be: []
  
  // c) let x = ['a', 'b', 'c', 'd']; fn(...x);
  // args will be: ['c', 'd']