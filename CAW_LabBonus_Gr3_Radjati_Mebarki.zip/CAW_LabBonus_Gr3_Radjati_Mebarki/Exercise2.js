//Q1
const arr = [3, 5, 8];
const plus_one = arr.map(n => n + 1);

console.log(plus_one);
//Q2
const double = arr => arr.map(val => val * 2);
console.log(double(arr));
//Q3
const obj = {
  numbers: {
    a: 1,
    b: 2
  }
};

const { a, b } = obj.numbers;
console.log(a,b);
//Q4
const add = (a, b) => {
    a = a === 0 ? 0 : a || 10;
    b = b === 0 ? 0 : b || 10;
    return a + b;
  };
  console.log(add(3,));