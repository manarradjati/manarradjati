 
const { mean } = require('./notation');  

test('calculates mean of positive numbers', () => {
    expect(mean([10, 20, 30, 40, 50])).toBe(30);
});

test('calculates mean with negative numbers', () => {
    expect(mean([-10, -20, -30, -40, -50])).toBe(-30);
});

test('calculates mean of an empty array', () => {
    expect(mean([])).toBe(0);
});

test('calculates mean of mixed numbers', () => {
    expect(mean([10, -10, 20, -20, 30])).toBe(6);
});

test('calculates mean of single number', () => {
    expect(mean([100])).toBe(100);
});
