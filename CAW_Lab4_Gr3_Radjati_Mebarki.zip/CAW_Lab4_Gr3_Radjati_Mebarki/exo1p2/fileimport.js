 
const { mean } = require('./notation');  

const scores = [70, 85, 90, 100, 60];
console.log("The mean score is:", mean(scores));
