const exf = require('./exf');  // Make sure exf.js is in the same directory

// Test case for Exercise 1
describe('Test exf function', () => {
  it('should repeat the string "echo" 5 times', () => {
    const result = exf("echo", 5);
    expect(result).toEqual(["echo", "echo", "echo", "echo", "echo"]);
  });

  it('should repeat the string "JS from server" 10 times', () => {
    const result = exf("JS from server", 10);
    expect(result).toEqual([
      "JS from server", "JS from server", "JS from server", "JS from server", "JS from server",
      "JS from server", "JS from server", "JS from server", "JS from server", "JS from server"
    ]);
  });
});

// Test case for Exercise 2 (testing edge cases and other inputs)
describe('Edge cases for exf function', () => {
  it('should return an empty array when the count is 0', () => {
    const result = exf("empty", 0);
    expect(result).toEqual([]);
  });

  it('should return an array with one string when the count is 1', () => {
    const result = exf("single", 1);
    expect(result).toEqual(["single"]);
  });

  it('should return an empty array for an empty string input', () => {
    const result = exf("", 5);
    expect(result).toEqual(["", "", "", "", ""]);
  });
});
