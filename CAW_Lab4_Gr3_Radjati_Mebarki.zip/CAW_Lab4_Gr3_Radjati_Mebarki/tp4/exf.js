function exf(s, n) {

  return Array(n).fill(s);
}

// Export the function to make it available for testing
module.exports = exf;