// arrayFunctions.test.js

// 1. Function to get the first n elements of an array
function first(array, n) {
    if (array == null || n <= 0) return [];
    if (n == null) return array[0];
    return array.slice(0, n);
}

// 2. Function to get the last n elements of an array
function last(array, n) {
    if (array == null) return [];
    if (n == null) return array[array.length - 1];
    return array.slice(Math.max(array.length - n, 0));
}

// 3. Array of strings concatenation examples
let myColor = ["Red", "Green", "White", "Black"];

// 4. Function to divide an array into sub-arrays of a specified size
function chunk(array, size) {
    var chunkedArr = [];
    var index = 0;
    while (index < array.length) {
        chunkedArr.push(array.slice(index, size + index));
        index += size;
    }
    return chunkedArr;
}

// Jest test cases
describe('first function', () => {
    test('returns first n elements', () => {
        expect(first([1, 2, 3, 4, 5], 2)).toEqual([1, 2]);
    });
    test('returns empty array if n is 0 or negative', () => {
        expect(first([1, 2, 3, 4, 5], 0)).toEqual([]);
        expect(first([1, 2, 3, 4, 5], -1)).toEqual([]);
    });
    test('returns first element if n is not provided', () => {
        expect(first([1, 2, 3, 4, 5])).toBe(1);
    });
    test('returns entire array if n is greater than array length', () => {
        expect(first([1, 2, 3, 4, 5], 10)).toEqual([1, 2, 3, 4, 5]);
    });
    test('handles empty and null arrays', () => {
        expect(first([], 3)).toEqual([]);
        expect(first(null, 3)).toEqual([]);
    });
});

describe('last function', () => {
    test('returns last n elements', () => {
        expect(last([1, 2, 3, 4, 5], 2)).toEqual([4, 5]);
    });
    test('returns empty array if n is 0 or negative', () => {
        expect(last([1, 2, 3, 4, 5], 0)).toEqual([]);
    });
    test('returns last element if n is not provided', () => {
        expect(last([1, 2, 3, 4, 5])).toBe(5);
    });
    test('returns entire array if n is greater than array length', () => {
        expect(last([1, 2, 3, 4, 5], 10)).toEqual([1, 2, 3, 4, 5]);
    });
    test('handles empty and null arrays', () => {
        expect(last([], 3)).toEqual([]);
        expect(last(null, 3)).toEqual([]);
    });
});

describe('myColor array concatenation', () => {
    test('joins with commas using toString', () => {
        expect(myColor.toString()).toBe("Red,Green,White,Black");
    });
    test('joins with commas using join()', () => {
        expect(myColor.join()).toBe("Red,Green,White,Black");
    });
    test('joins without separator using join("")', () => {
        expect(myColor.join('')).toBe("RedGreenWhiteBlack");
    });
});

describe('chunk function', () => {
    test('divides array into sub-arrays of specified size', () => {
        expect(chunk([1, 2, 3, 4, 5], 2)).toEqual([[1, 2], [3, 4], [5]]);
    });
    test('handles exact multiples of chunk size', () => {
        expect(chunk([1, 2, 3, 4, 5, 6], 3)).toEqual([[1, 2, 3], [4, 5, 6]]);
    });
    test('creates individual arrays if chunk size is 1', () => {
        expect(chunk([1, 2, 3, 4, 5], 1)).toEqual([[1], [2], [3], [4], [5]]);
    });
    test('returns entire array in one chunk if size is larger than array length', () => {
        expect(chunk([1, 2, 3, 4, 5], 10)).toEqual([[1, 2, 3, 4, 5]]);
    });
    test('handles empty array', () => {
        expect(chunk([], 2)).toEqual([]);
    });
});
