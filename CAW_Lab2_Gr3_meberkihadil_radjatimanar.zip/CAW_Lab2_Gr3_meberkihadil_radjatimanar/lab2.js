var boundaries = document.querySelectorAll('.boundary');
var gameLost = false;  // flag to track if the player has lost

// When the mouse touches a boundary, the player loses
boundaries.forEach(function(boundary) {
    boundary.addEventListener('mouseover', function() {
        gameLost = true;
        boundaries.forEach(function(b) {
            b.classList.add('youlose');  // make all boundaries red
        });
        document.getElementById('status').textContent = 'You Lose!';
    });
});

var win = document.getElementById('end');

// When the mouse reaches the end, check if the player lost
win.addEventListener('mouseover', function() {
    if (!gameLost) {
        alert('You win!');
    } else {
        alert('You already lost!');
    }
});

// Reset the game when the mouse enters the "S" (start) area
document.getElementById('start').addEventListener('mouseover', function() {
    gameLost = false;
    boundaries.forEach(function(b) {
        b.classList.remove('youlose');  // reset boundary color
    });
    document.getElementById('status').textContent = 'Move your mouse over the "S" to begin.';
});
