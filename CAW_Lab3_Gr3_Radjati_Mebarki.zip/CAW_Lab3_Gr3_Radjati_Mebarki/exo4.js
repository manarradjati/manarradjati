 //part1....................................
/*const fs = require('fs');


const text = process.argv[2];

 
if (!text) {
  console.error("Please provide text to be saved.");
  process.exit(1);
}

 
fs.writeFile('f.txt', text, 'utf8', (err) => {
  if (err) {
    console.error("Error saving the file:", err.message);
    return;
  }
  console.log("The file has been saved!");
});
*/
//part2................................
/*const fs = require('fs');

// Get the file name and text from command-line arguments
const fileName = process.argv[2];
const text = process.argv[3];


if (!fileName || !text) {
  console.error("Please provide both the file name and text to be saved.");
  process.exit(1);
}

 
fs.writeFile(fileName, text, 'utf8', (err) => {
  if (err) {
    console.error("Error saving the file:", err.message);
    return;
  }
  console.log("The file has been saved!");
});
*/
//part3............................................
const fs = require('fs');

 
const fileName = process.argv[2];
const text = process.argv[3];

 
if (!fileName || !text) {
  console.error("Please provide both the file name and text to be saved.");
  process.exit(1);
}

 
fs.writeFile(fileName, text, 'utf8', (err) => {
  if (err) {
    console.error("Error saving the file:", err.message);
    return;
  }
  console.log("The file has been saved!");

   
  fs.readFile(fileName, 'utf8', (err, data) => {
    if (err) {
      console.error("Error reading the file:", err.message);
      return;
    }
    console.log("File content:");
    console.log(data);
  });
});
